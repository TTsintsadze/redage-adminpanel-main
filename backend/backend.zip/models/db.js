let mysql = require('mysql');

const dbconnectionData = {
	admin: {
		host: '137.74.4.135',
		port: 3306,
		user: 'redage_dev',
		password: 'fUsTBJFtW7VUqytU',
		database: 'ra3_main',
		socketPath: null,  // общаемся с mysql через сокеты
	},
	basicTest: {
		host: '137.74.4.135',
		port: 3306,
		user: 'redage_dev',
		password: 'fUsTBJFtW7VUqytU',
		database: 'ra3_mainconfig',
		socketPath: null,  // общаемся с mysql через сокеты
	},
	logsTest: {
		host: '137.74.4.135',
		port: 3306,
		user: 'redage_dev',
		password: 'fUsTBJFtW7VUqytU',
		database: 'ra3_mainlogs',
		socketPath: null,  // общаемся с mysql через сокеты
	},
}

module.exports.createPool = (name) => {
	if (name && dbconnectionData [name]) {
		const db = dbconnectionData [name];
		return mysql.createPool({
			host: db.host,
			port: db.port,
			user: db.user,
			password: db.password,
			database: db.database,
			socketPath: db.socketPath,  // общаемся с mysql через сокеты
			connectionLimit: 100
		})
	}
	return null;
};

module.exports.query = function(pool, sql, props = []) {
	return new Promise(function (resolve, reject) {
		pool.getConnection(function (err, connection) {
            if (err) throw err; // not connected!
			connection.query(sql, props, function (err, res) {
				if (err)
					reject(err);
				else
                    resolve(res);
			});
			connection.release();
		});
	});
};